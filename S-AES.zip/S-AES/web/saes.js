/*
 * S-AES 前端实现（与 Python 版本逐行对应，可互相验证）
 * 仅用于课堂演示，不做任何网络请求，所有计算都在浏览器本地完成。
 */
(function (global) {
  'use strict';

  var SBOX = [0x9, 0x4, 0xA, 0xB, 0xD, 0x1, 0x8, 0x5,
              0x6, 0x2, 0x0, 0x3, 0xC, 0xE, 0xF, 0x7];
  var INV_SBOX = new Array(16);
  for (var i = 0; i < 16; i++) { INV_SBOX[SBOX[i]] = i; }

  var RCON1 = 0x80, RCON2 = 0x30;

  /* ---------------- GF(2^4) ---------------- */
  function gmul(a, b) {
    var p = 0;
    for (var i = 0; i < 4; i++) {
      if (b & 1) { p ^= a; }
      var carry = a & 0x8;
      a = (a << 1) & 0xF;
      if (carry) { a ^= 0x3; }
      b >>= 1;
    }
    return p & 0xF;
  }

  function nibbles(v) {
    return [(v >> 12) & 0xF, (v >> 8) & 0xF, (v >> 4) & 0xF, v & 0xF];
  }
  function pack(n) {
    return ((n[0] << 12) | (n[1] << 8) | (n[2] << 4) | n[3]) & 0xFFFF;
  }
  function hex(v, width) {
    return (v >>> 0).toString(16).toUpperCase().padStart(width || 4, '0');
  }
  function bin(v, width) {
    return (v >>> 0).toString(2).padStart(width || 4, '0');
  }

  /* ---------------- 密钥扩展 ---------------- */
  function rotNib(w) { return ((w & 0x0F) << 4) | ((w >> 4) & 0x0F); }
  function subNib(w) { return (SBOX[(w >> 4) & 0xF] << 4) | SBOX[w & 0xF]; }
  function gFunc(w, rcon) { return subNib(rotNib(w)) ^ rcon; }

  function expandKeyWords(key) {
    key &= 0xFFFF;
    var w0 = (key >> 8) & 0xFF, w1 = key & 0xFF;
    var w2 = w0 ^ gFunc(w1, RCON1);
    var w3 = w2 ^ w1;
    var w4 = w2 ^ gFunc(w3, RCON2);
    var w5 = w4 ^ w3;
    return [w0, w1, w2, w3, w4, w5];
  }
  function expandKey(key) {
    var w = expandKeyWords(key);
    return [((w[0] << 8) | w[1]), ((w[2] << 8) | w[3]), ((w[4] << 8) | w[5])];
  }

  /* ---------------- 轮变换 ---------------- */
  function subBytes(s) {
    var n = nibbles(s);
    return pack([SBOX[n[0]], SBOX[n[1]], SBOX[n[2]], SBOX[n[3]]]);
  }
  function invSubBytes(s) {
    var n = nibbles(s);
    return pack([INV_SBOX[n[0]], INV_SBOX[n[1]], INV_SBOX[n[2]], INV_SBOX[n[3]]]);
  }
  function shiftRows(s) {
    var n = nibbles(s); var t = n[1]; n[1] = n[3]; n[3] = t; return pack(n);
  }
  var invShiftRows = shiftRows;
  function mixColumns(s) {
    var n = nibbles(s);
    return pack([
      n[0] ^ gmul(4, n[1]),
      gmul(4, n[0]) ^ n[1],
      n[2] ^ gmul(4, n[3]),
      gmul(4, n[2]) ^ n[3]
    ]);
  }
  function invMixColumns(s) {
    var n = nibbles(s);
    return pack([
      gmul(9, n[0]) ^ gmul(2, n[1]),
      gmul(2, n[0]) ^ gmul(9, n[1]),
      gmul(9, n[2]) ^ gmul(2, n[3]),
      gmul(2, n[2]) ^ gmul(9, n[3])
    ]);
  }

  /* ---------------- 单分组 ---------------- */
  function encryptBlock(pt, key) { return traceEncrypt(pt, key).cipher; }
  function decryptBlock(ct, key) { return traceDecrypt(ct, key).plain; }

  function traceEncrypt(pt, key) {
    var ks = expandKey(key);
    var w = expandKeyWords(key);
    var steps = [];
    var s = (pt ^ ks[0]) & 0xFFFF;
    steps.push({ label: '轮密钥加 K0', value: s });

    s = subBytes(s); steps.push({ label: '第 1 轮 · 半字节替换', value: s });
    s = shiftRows(s); steps.push({ label: '第 1 轮 · 行移位', value: s });
    s = mixColumns(s); steps.push({ label: '第 1 轮 · 列混淆', value: s });
    s = (s ^ ks[1]) & 0xFFFF; steps.push({ label: '第 1 轮 · 轮密钥加 K1', value: s });

    s = subBytes(s); steps.push({ label: '第 2 轮 · 半字节替换', value: s });
    s = shiftRows(s); steps.push({ label: '第 2 轮 · 行移位', value: s });
    s = (s ^ ks[2]) & 0xFFFF; steps.push({ label: '第 2 轮 · 轮密钥加 K2', value: s });

    return { cipher: s, steps: steps, roundKeys: ks, words: w };
  }

  function traceDecrypt(ct, key) {
    var ks = expandKey(key);
    var steps = [];
    var s = (ct ^ ks[2]) & 0xFFFF;
    steps.push({ label: '轮密钥加 K2', value: s });

    s = invShiftRows(s); steps.push({ label: '逆第 2 轮 · 逆行移位', value: s });
    s = invSubBytes(s); steps.push({ label: '逆第 2 轮 · 逆半字节替换', value: s });
    s = (s ^ ks[1]) & 0xFFFF; steps.push({ label: '逆第 2 轮 · 轮密钥加 K1', value: s });
    s = invMixColumns(s); steps.push({ label: '逆第 2 轮 · 逆列混淆', value: s });

    s = invShiftRows(s); steps.push({ label: '逆第 1 轮 · 逆行移位', value: s });
    s = invSubBytes(s); steps.push({ label: '逆第 1 轮 · 逆半字节替换', value: s });
    s = (s ^ ks[0]) & 0xFFFF; steps.push({ label: '逆第 1 轮 · 轮密钥加 K0', value: s });

    return { plain: s, steps: steps, roundKeys: ks };
  }

  /* ---------------- 多重加密 ---------------- */
  function encryptBlockMulti(block, keys) {
    if (keys.length === 1) { return encryptBlock(block, keys[0]); }
    if (keys.length === 2) { return encryptBlock(encryptBlock(block, keys[0]), keys[1]); }
    return encryptBlock(decryptBlock(encryptBlock(block, keys[0]), keys[1]), keys[2]);
  }
  function decryptBlockMulti(block, keys) {
    if (keys.length === 1) { return decryptBlock(block, keys[0]); }
    if (keys.length === 2) { return decryptBlock(decryptBlock(block, keys[1]), keys[0]); }
    return decryptBlock(encryptBlock(decryptBlock(block, keys[2]), keys[1]), keys[0]);
  }

  /* ---------------- 填充与工作模式 ---------------- */
  function pad(bytes) {
    var n = 2 - (bytes.length % 2);
    var out = bytes.slice();
    for (var i = 0; i < n; i++) { out.push(n); }
    return out;
  }
  function unpad(bytes) {
    if (!bytes.length || bytes.length % 2 !== 0) {
      throw new Error('密文长度不是 2 字节的整数倍');
    }
    var n = bytes[bytes.length - 1];
    if (n < 1 || n > 2) { throw new Error('填充值非法，密钥或 IV 可能错误'); }
    for (var i = bytes.length - n; i < bytes.length; i++) {
      if (bytes[i] !== n) { throw new Error('填充内容不一致，密钥或 IV 可能错误'); }
    }
    return bytes.slice(0, bytes.length - n);
  }

  function encryptBytes(bytes, keys, chain, iv) {
    var data = pad(bytes);
    var out = [];
    var prev = (iv || 0) & 0xFFFF;
    for (var i = 0; i < data.length; i += 2) {
      var block = (data[i] << 8) | data[i + 1];
      var input = chain === 'cbc' ? (block ^ prev) : block;
      var c = encryptBlockMulti(input, keys);
      out.push((c >> 8) & 0xFF, c & 0xFF);
      if (chain === 'cbc') { prev = c; }
    }
    return out;
  }

  function decryptBytes(bytes, keys, chain, iv) {
    if (bytes.length % 2 !== 0) { throw new Error('密文长度必须是 2 字节的整数倍'); }
    var out = [];
    var prev = (iv || 0) & 0xFFFF;
    for (var i = 0; i < bytes.length; i += 2) {
      var block = (bytes[i] << 8) | bytes[i + 1];
      var p = decryptBlockMulti(block, keys);
      if (chain === 'cbc') { p = p ^ prev; prev = block; }
      out.push((p >> 8) & 0xFF, p & 0xFF);
    }
    return unpad(out);
  }

  /* ---------------- 文本工具 ---------------- */
  function utf8Bytes(text) {
    return Array.from(new TextEncoder().encode(text));
  }
  function bytesToHex(bytes) {
    return bytes.map(function (b) { return b.toString(16).toUpperCase().padStart(2, '0'); }).join('');
  }
  function hexToBytes(str) {
    var clean = str.replace(/[^0-9a-fA-F]/g, '');
    if (clean.length % 2 !== 0) { throw new Error('十六进制长度必须是偶数'); }
    var out = [];
    for (var i = 0; i < clean.length; i += 2) { out.push(parseInt(clean.substr(i, 2), 16)); }
    return out;
  }
  function bytesToText(bytes) {
    try {
      return new TextDecoder('utf-8', { fatal: true }).decode(new Uint8Array(bytes));
    } catch (e) {
      return null;
    }
  }

  global.SAES = {
    SBOX: SBOX,
    INV_SBOX: INV_SBOX,
    gmul: gmul,
    nibbles: nibbles,
    pack: pack,
    hex: hex,
    bin: bin,
    expandKey: expandKey,
    expandKeyWords: expandKeyWords,
    encryptBlock: encryptBlock,
    decryptBlock: decryptBlock,
    traceEncrypt: traceEncrypt,
    traceDecrypt: traceDecrypt,
    encryptBlockMulti: encryptBlockMulti,
    decryptBlockMulti: decryptBlockMulti,
    encryptBytes: encryptBytes,
    decryptBytes: decryptBytes,
    utf8Bytes: utf8Bytes,
    bytesToHex: bytesToHex,
    hexToBytes: hexToBytes,
    bytesToText: bytesToText
  };
})(this);
