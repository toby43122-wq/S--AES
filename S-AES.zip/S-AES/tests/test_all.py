# -*- coding: utf-8 -*-
"""
S-AES 测试套件
==============

运行方式：
    python -m unittest discover -s tests -v
    # 或
    python main.py test

覆盖内容：
    1. S 盒 / 逆 S 盒自洽性，以及 S 盒能否由“求逆 + 仿射变换”算出来
    2. 密钥扩展与教科书例题
    3. 教科书附录 D 的标准测试向量
    4. 穷举测试：所有明文、所有密钥都能正确解密回原文
    5. 多重加密（2 重 / 3 重）的互逆性与 EDE 结构
    6. CBC / ECB 两种模式的互逆性、填充规则、密文长度
    7. ECB 泄露重复模式、CBC 不泄露（教学验证）
    8. 篡改检测（填充校验）
    9. 组间测试协议文件（data/vectors.json）
"""

import json
import os
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from saes import (INV_SBOX, SBOX, build_sbox, decrypt_block, decrypt_block_trace,
                  encrypt_block, encrypt_block_trace, expand_key,
                  expand_key_words, gmul, ginv, hex16)
from modes import (ascii_preview, ascii_to_bytes, bytes_to_ascii, check_keys,
                   decrypt_block_multi, decrypt_data, encrypt_block_multi,
                   encrypt_data, flip_bit, join_key32, pad, parse_key_text,
                   split_key32, split_key48, triple_keys_from_32, unpad)
from attack import double_encrypt, meet_in_the_middle
from vectors import build_spec, verify_spec


class TestMathAndTables(unittest.TestCase):
    """GF(2^4) 与 S 盒"""

    def test_sbox_matches_textbook(self):
        self.assertEqual(build_sbox(), SBOX,
                         "S 盒应等于 逆元 + 仿射变换 的计算结果（表 D.1）")

    def test_inverse_sbox_consistent(self):
        for x in range(16):
            self.assertEqual(INV_SBOX[SBOX[x]], x)
            self.assertEqual(SBOX[INV_SBOX[x]], x)

    def test_gf_multiplication(self):
        # 单位元、交换律、分配律
        for a in range(16):
            self.assertEqual(gmul(a, 1), a)
            self.assertEqual(gmul(a, 0), 0)
            for b in range(16):
                self.assertEqual(gmul(a, b), gmul(b, a))
        for a in range(16):
            for b in range(16):
                for c in range(16):
                    self.assertEqual(gmul(a, b ^ c), gmul(a, b) ^ gmul(a, c))

    def test_gf_inverse(self):
        for a in range(1, 16):
            self.assertEqual(gmul(a, ginv(a)), 1)

    def test_gmul_known_values(self):
        # 教科书中列混淆用到的几个乘积
        self.assertEqual(gmul(4, 9), 2)
        self.assertEqual(gmul(9, 2), 1)


class TestKeyExpansion(unittest.TestCase):
    """密钥扩展"""

    def test_textbook_key_2d55(self):
        w = expand_key_words(0x2D55)
        self.assertEqual(w[0], 0x2D)
        self.assertEqual(w[1], 0x55)
        self.assertEqual(w[2], 0xBC)
        self.assertEqual(w[3], 0xE9)
        self.assertEqual(w[4], 0xA3)
        self.assertEqual(w[5], 0x4A)
        self.assertEqual(expand_key(0x2D55), (0x2D55, 0xBCE9, 0xA34A))

    def test_zero_key(self):
        self.assertEqual(expand_key(0x0000), (0x0000, 0x1919, 0x0D14))

    def test_all_keys_have_three_round_keys(self):
        for key in (0x0000, 0x0001, 0x7FFF, 0x8000, 0xFFFF, 0x2D55):
            ks = expand_key(key)
            self.assertEqual(len(ks), 3)
            self.assertEqual(ks[0], key)


class TestKnownVectors(unittest.TestCase):
    """标准测试向量"""

    def test_textbook_vector(self):
        """教科书附录 D 的完整例子：6BA3 + 2D55 = 3C3B"""
        self.assertEqual(encrypt_block(0x6BA3, 0x2D55), 0x3C3B)
        self.assertEqual(decrypt_block(0x3C3B, 0x2D55), 0x6BA3)

    def test_second_reference_vector(self):
        """另一组常用参考向量：D728 + 4AF5 = 24EC"""
        self.assertEqual(encrypt_block(0xD728, 0x4AF5), 0x24EC)
        self.assertEqual(decrypt_block(0x24EC, 0x4AF5), 0xD728)

    def test_trace_matches_block(self):
        ct, steps, w = encrypt_block_trace(0x6BA3, 0x2D55)
        self.assertEqual(ct, encrypt_block(0x6BA3, 0x2D55))
        self.assertEqual(len(steps), 8)          # 轮密钥加 K0 + 第一轮 4 步 + 第二轮 3 步
        self.assertEqual(steps[-1][1], ct)

    def test_decrypt_trace_matches_block(self):
        pt, steps = decrypt_block_trace(0x3C3B, 0x2D55)
        self.assertEqual(pt, 0x6BA3)
        self.assertEqual(steps[-1][1], pt)


class TestExhaustive(unittest.TestCase):
    """穷举测试：S-AES 状态空间只有 2^16，可以全部跑一遍"""

    def test_all_plaintexts_roundtrip(self):
        for key in (0x2D55, 0x0000):
            for pt in range(0x10000):
                self.assertEqual(decrypt_block(encrypt_block(pt, key), key), pt,
                                 "key=%s pt=%s" % (hex16(key), hex16(pt)))

    def test_all_keys_roundtrip(self):
        for key in range(0x10000):
            self.assertEqual(decrypt_block(encrypt_block(0x6BA3, key), key), 0x6BA3,
                             "key=%s" % hex16(key))


class TestMultipleEncryption(unittest.TestCase):
    """多重加密（对应第 9 讲 2DES / 3DES）"""

    def test_double_roundtrip(self):
        keys = [0x2D55, 0xA1B2]
        for pt in (0x0000, 0x6BA3, 0xFFFF, 0x1234):
            ct = encrypt_block_multi(pt, keys)
            self.assertEqual(decrypt_block_multi(ct, keys), pt)

    def test_triple_is_ede(self):
        """三重加密必须是 加密→解密→加密 的 EDE 结构"""
        k1, k2, k3 = 0x2D55, 0xA1B2, 0x0F0F
        pt = 0x6BA3
        manual = encrypt_block(
            decrypt_block(encrypt_block(pt, k1), k2), k3)
        self.assertEqual(encrypt_block_multi(pt, [k1, k2, k3]), manual)

    def test_triple_with_same_key_equals_single(self):
        """三把钥匙相同时，EDE 退化为单重加密（3DES 的经典性质）"""
        k = 0x2D55
        self.assertEqual(encrypt_block_multi(0x6BA3, [k, k, k]),
                         encrypt_block(0x6BA3, k))

    def test_double_not_equal_single(self):
        self.assertNotEqual(encrypt_block_multi(0x6BA3, [0x2D55, 0xA1B2]),
                            encrypt_block(0x6BA3, 0x2D55))


class TestPadding(unittest.TestCase):
    def test_pad_unpad_roundtrip(self):
        for n in range(0, 20):
            data = bytes(range(n))
            self.assertEqual(unpad(pad(data)), data)

    def test_pad_always_full_block(self):
        for n in range(0, 20):
            self.assertEqual(len(pad(bytes(n))) % 2, 0)
            self.assertGreater(len(pad(bytes(n))), n)

    def test_unpad_rejects_bad_padding(self):
        with self.assertRaises(ValueError):
            unpad(b"\x00\x05")
        with self.assertRaises(ValueError):
            unpad(b"\x00")          # 长度不是分组整数倍


class TestModes(unittest.TestCase):
    """ECB / CBC 工作模式"""

    def test_ecb_roundtrip(self):
        keys = [0x2D55]
        for text in ["", "A", "AB", "ABC", "信息安全导论", "x" * 100]:
            data = text.encode("utf-8")
            ct = encrypt_data(data, keys, "ecb")
            self.assertEqual(decrypt_data(ct, keys, "ecb"), data)

    def test_cbc_roundtrip(self):
        for keys in ([0x2D55], [0x2D55, 0xA1B2], [0x2D55, 0xA1B2, 0x0F0F]):
            for iv in (0x0000, 0x1234, 0xFFFF):
                for text in ["", "A", "AB", "ABC", "信息安全导论 - S-AES", "y" * 257]:
                    data = text.encode("utf-8")
                    ct = encrypt_data(data, keys, "cbc", iv)
                    self.assertEqual(decrypt_data(ct, keys, "cbc", iv), data,
                                     "keys=%r iv=%s len=%d" % (keys, iv, len(data)))

    def test_ciphertext_length(self):
        for n in range(0, 12):
            ct = encrypt_data(bytes(n), [0x2D55], "cbc", 0x1234)
            self.assertEqual(len(ct), len(pad(bytes(n))))

    def test_ecb_leaks_repetition(self):
        """相同明文块 -> 相同密文块，这是 ECB 的缺陷（第 9 讲重点）"""
        data = bytes([0x6B, 0xA3] * 4)
        ct = encrypt_data(data, [0x2D55], "ecb")
        blocks = [ct[i:i + 2] for i in range(0, len(ct), 2)]
        # 末尾多出来的是填充块，比较前 4 个真正的数据块
        self.assertEqual(len(set(blocks[:-1])), 1)

    def test_cbc_hides_repetition(self):
        data = bytes([0x6B, 0xA3] * 4)
        ct = encrypt_data(data, [0x2D55], "cbc", 0x1234)
        blocks = [ct[i:i + 2] for i in range(0, len(ct), 2)]
        self.assertGreater(len(set(blocks[:-1])), 1)

    def test_cbc_iv_changes_ciphertext(self):
        data = b"hello"
        a = encrypt_data(data, [0x2D55], "cbc", 0x0000)
        b = encrypt_data(data, [0x2D55], "cbc", 0x0001)
        self.assertNotEqual(a, b)

    def test_wrong_key_or_iv_cannot_recover(self):
        """
        密钥或 IV 错误时不能还原原文。
        注意：S-AES 分组只有 16 bit，PKCS#7 填充校验的“拦截率”很低
        （只有 1/256 + 1/65536 的随机数据会被判为合法填充），
        所以这里断言“结果不正确”，而不是“一定抛异常”。
        真实系统必须配 MAC/认证加密，README 的安全讨论里有说明。
        """
        data = b"hello world"
        ct = encrypt_data(data, [0x2D55], "cbc", 0x1234)
        for keys, iv in (([0x2D55], 0x0001), ([0xA1B2], 0x1234)):
            try:
                out = decrypt_data(ct, keys, "cbc", iv)
            except ValueError:
                continue          # 填充校验拦住了，也算正确行为
            self.assertNotEqual(out, data)

    def test_invalid_chain(self):
        with self.assertRaises(ValueError):
            encrypt_data(b"x", [0x2D55], "ctr")

    def test_check_keys(self):
        self.assertEqual(check_keys(0x2D55), [0x2D55])
        with self.assertRaises(ValueError):
            check_keys([1, 2, 3, 4])


class TestKeyFormats(unittest.TestCase):
    """第 4 关：32 bit / 48 bit 密钥的拆分与解析"""

    def test_split_key32(self):
        self.assertEqual(split_key32(0x2D55A1B2), (0x2D55, 0xA1B2))
        self.assertEqual(join_key32(0x2D55, 0xA1B2), 0x2D55A1B2)

    def test_split_key48(self):
        self.assertEqual(split_key48(0x2D55A1B20F0F), (0x2D55, 0xA1B2, 0x0F0F))

    def test_parse_key_text(self):
        self.assertEqual(parse_key_text("2D55"), [0x2D55])
        self.assertEqual(parse_key_text("2d55a1b2"), [0x2D55, 0xA1B2])
        self.assertEqual(parse_key_text("2D55 A1B2 0F0F"), [0x2D55, 0xA1B2, 0x0F0F])
        with self.assertRaises(ValueError):
            parse_key_text("")
        with self.assertRaises(ValueError):
            parse_key_text("2D5G")
        with self.assertRaises(ValueError):
            parse_key_text("2D5")          # 长度不合法

    def test_triple_with_32bit_key(self):
        """三重加密（32 bit）等价于 K1 加密 → K2 解密 → K1 加密"""
        keys = triple_keys_from_32(0x2D55A1B2)
        self.assertEqual(keys, [0x2D55, 0xA1B2, 0x2D55])
        expected = encrypt_block(
            decrypt_block(encrypt_block(0x6BA3, 0x2D55), 0xA1B2), 0x2D55)
        self.assertEqual(encrypt_block_multi(0x6BA3, keys), expected)

    def test_double_and_triple_vectors(self):
        self.assertEqual(encrypt_block_multi(0x6BA3, [0x2D55, 0xA1B2]), 0x887F)
        self.assertEqual(encrypt_block_multi(0x6BA3, [0x2D55, 0xA1B2, 0x2D55]), 0x897B)
        self.assertEqual(encrypt_block_multi(0x6BA3, [0x2D55, 0xA1B2, 0x0F0F]), 0xCB36)


class TestAsciiSupport(unittest.TestCase):
    """第 3 关：ASCII 字符串"""

    def test_ascii_roundtrip(self):
        text = "Hello, S-AES!"
        data = ascii_to_bytes(text)
        self.assertEqual(len(data), len(text))
        self.assertEqual(bytes_to_ascii(data), text)

    def test_ascii_rejects_non_ascii(self):
        with self.assertRaises(ValueError):
            ascii_to_bytes("信息安全")

    def test_ascii_encrypt_decrypt(self):
        plain = ascii_to_bytes("Hello!")
        cipher = encrypt_data(plain, [0x2D55])
        self.assertEqual(cipher.hex().upper(), "E90156CDFE5323DF")
        self.assertEqual(decrypt_data(cipher, [0x2D55]), plain)

    def test_ascii_preview(self):
        self.assertEqual(ascii_preview(b"A\x00B"), "A·B")


class TestTamper(unittest.TestCase):
    """第 5 关：密文篡改"""

    def test_flip_bit_changes_exactly_one_bit(self):
        data = bytes.fromhex("5E211170FF29")
        broken = flip_bit(data, 1, 3)
        self.assertEqual(len(broken), len(data))
        diff = [index for index in range(len(data)) if data[index] != broken[index]]
        self.assertEqual(len(diff), 1)          # 只改动了一个字节
        diff_bits = bin(data[diff[0]] ^ broken[diff[0]]).count("1")
        self.assertEqual(diff_bits, 1)          # 且只翻转了一位

    def test_flip_bit_out_of_range(self):
        with self.assertRaises(ValueError):
            flip_bit(b"\x00\x01", 5, 1)
        with self.assertRaises(ValueError):
            flip_bit(b"\x00\x01", 0, 17)

    def test_cbc_error_propagation(self):
        """
        CBC 下篡改第 i 个分组：
            第 i 个明文分组整块乱掉，第 i+1 个分组只翻转对应的一位，再往后不受影响。
        """
        key, iv = 0x2D55, 0x1234
        plain = bytes(range(0x20, 0x20 + 12))    # 12 字节 = 6 个分组
        cipher = encrypt_data(plain, [key], "cbc", iv)
        broken = flip_bit(cipher, 0, 1)

        original = decrypt_data(cipher, [key], "cbc", iv)
        damaged = decrypt_data(broken, [key], "cbc", iv)

        self.assertEqual(original, plain)
        self.assertNotEqual(damaged[0:2], plain[0:2])       # 第 0 块乱掉
        self.assertNotEqual(damaged[2:4], plain[2:4])       # 第 1 块翻转一位
        self.assertEqual(damaged[4:], plain[4:])            # 之后不受影响


class TestMeetInTheMiddle(unittest.TestCase):
    """第 4 关 4.2：中间相遇攻击"""

    def test_recover_double_key(self):
        real_key1, real_key2 = 0x2D55, 0xA1B2
        pairs = [(plain, double_encrypt(plain, real_key1, real_key2))
                 for plain in (0x6BA3, 0x1234, 0xABCD)]
        survivors, stats = meet_in_the_middle(pairs)
        self.assertEqual(stats["keys_scanned"], 0x10000)
        self.assertIn((real_key1, real_key2), survivors)
        self.assertEqual(len(survivors), 1, "三组明密文对应当唯一确定密钥")


class TestInteropVectors(unittest.TestCase):
    """组间测试协议文件"""

    def test_vectors_file(self):
        path = os.path.join(ROOT, "data", "vectors.json")
        if not os.path.exists(path):
            self.skipTest("还没有生成 data/vectors.json")
        with open(path, "r", encoding="utf-8") as f:
            spec = json.load(f)
        self.assertIn("cases", spec)
        self.assertGreater(len(spec["cases"]), 0)
        for case in spec["cases"]:
            keys = [int(k, 16) for k in case["keys"]]
            chain = case.get("chain", "ecb")
            iv = int(case.get("iv", "0000"), 16)
            if case.get("hex_data"):
                got = encrypt_data(bytes.fromhex(case["plaintext"]), keys, chain, iv)
                self.assertEqual(got.hex().upper(), case["ciphertext"].upper(), case["desc"])
                back = decrypt_data(bytes.fromhex(case["ciphertext"]), keys, chain, iv)
                self.assertEqual(back.hex().upper(), case["plaintext"].upper(), case["desc"])
            else:
                got = encrypt_block_multi(int(case["plaintext"], 16), keys)
                self.assertEqual(hex16(got), case["ciphertext"].upper(), case["desc"])
                back = decrypt_block_multi(int(case["ciphertext"], 16), keys)
                self.assertEqual(hex16(back), case["plaintext"].upper(), case["desc"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
