# -*- coding: utf-8 -*-
"""
自动截取图形界面各页签的截图（用于测试报告）
============================================

用法（需要 Pillow）：
    python tools/capture_gui.py

输出：docs/images/level1.png ~ level5.png

说明：
    这是开发时用来生成文档截图的小工具，不参与算法逻辑。
    截图前会先让各页显示出真实结果，避免交上去的是空白界面。
"""

import ctypes
import os
import sys
import time

# 让窗口坐标与截图像素一一对应（避免高 DPI 缩放导致裁偏）
try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)
except Exception:
    pass

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from PIL import ImageGrab

import gui
from attack import meet_in_the_middle
from vectors import load, VECTORS_PATH


def prepare_level2(app):
    app._verify_and_show(load(VECTORS_PATH))


def prepare_level3(app):
    app.txt_ascii_in.delete("1.0", "end")
    app.txt_ascii_in.insert("1.0", "Hello, S-AES!")
    app._on_ascii_encrypt()


def prepare_level4(app):
    app.e_key4.delete(0, "end")
    app.e_key4.insert(0, "2D55A1B2")
    app.var_multi_mode.set("double")
    app._refresh_key_split()
    app._on_multi_encrypt()
    app._on_fill_pairs()
    pairs = app._read_pairs()
    survivors, stats = meet_in_the_middle(pairs)
    app._show_mitm(survivors, stats, 2.01)


def prepare_level5(app):
    app._on_cbc_encrypt()
    app.spin_block.set(1)
    app.spin_bit.set(3)
    app._on_tamper()


def main():
    out_dir = os.path.join(ROOT, "docs", "images")
    os.makedirs(out_dir, exist_ok=True)

    app = gui.SAESApp()
    app.geometry("1060x800+40+40")
    app.attributes("-topmost", True)
    app.update()
    time.sleep(0.6)

    preparers = [None, prepare_level2, prepare_level3, prepare_level4, prepare_level5]
    names = ["level1", "level2", "level3", "level4", "level5"]

    for index, name in enumerate(names):
        app.notebook.select(index)
        app.update()
        if preparers[index]:
            preparers[index](app)
            app.update()
        time.sleep(0.5)

        x, y = app.winfo_rootx(), app.winfo_rooty()
        width, height = app.winfo_width(), app.winfo_height()
        image = ImageGrab.grab(bbox=(x, y, x + width, y + height))
        path = os.path.join(out_dir, name + ".png")
        image.save(path)
        print("已保存 %s  (%d x %d)" % (path, width, height))

    app.destroy()


if __name__ == "__main__":
    main()
