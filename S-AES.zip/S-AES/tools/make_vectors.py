# -*- coding: utf-8 -*-
"""
生成组间交叉测试向量 data/vectors.json
====================================

用法：
    python tools/make_vectors.py

向量的定义在 vectors.py 里，这里只负责生成并打印摘要。
其中 #1 与教科书附录 D 的答案 3C3B 对齐，是双方对齐的“锚点”。
"""

import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from vectors import build_spec, save


def main():
    path = save()
    spec = build_spec()
    print("已生成 %s（%d 条用例）" % (path, len(spec["cases"])))
    for case in spec["cases"]:
        print("  #%d [第%s关] %-36s %s -> %s"
              % (case["id"], case["level"], case["desc"],
                 case["plaintext"], case["ciphertext"]))
    assert spec["cases"][0]["ciphertext"] == "3C3B", "教材例题未通过，检查实现"


if __name__ == "__main__":
    main()
