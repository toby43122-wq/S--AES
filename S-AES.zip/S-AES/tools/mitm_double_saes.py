# -*- coding: utf-8 -*-
"""
中间相遇攻击演示（命令行版）
============================

对应作业第 4 关 4.2。攻击逻辑在 attack.py 里，这里只负责演示与讲解。

运行：
    python tools/mitm_double_saes.py
"""

import os
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from attack import double_encrypt, meet_in_the_middle
from saes import hex16


def main():
    print("=" * 66)
    print("  双重 S-AES 的中间相遇攻击")
    print("=" * 66)

    real_key1, real_key2 = 0x2D55, 0xA1B2
    samples = (0x6BA3, 0x1234, 0xABCD)
    pairs = [(plain, double_encrypt(plain, real_key1, real_key2)) for plain in samples]

    print("真实密钥      : K1 = %s, K2 = %s（Key = %s）"
          % (hex16(real_key1), hex16(real_key2),
             hex16((real_key1 << 16) | real_key2, 8)))
    print("已知明密文对  :")
    for plain, cipher in pairs:
        print("    %s -> %s" % (hex16(plain), hex16(cipher)))

    started = time.time()
    survivors, stats = meet_in_the_middle(pairs)
    elapsed = time.time() - started

    print("\n正向表        : 2^16 = %d 个中间值" % stats["keys_scanned"])
    print("首次命中      : %d 组候选" % stats["first_hits"])
    print("过滤后剩余    : %d 组" % stats["survivors"])
    for key1, key2 in survivors:
        print("  恢复出 K1 = %s, K2 = %s  %s"
              % (hex16(key1), hex16(key2),
                 "✔ 与真实密钥一致" if (key1, key2) == (real_key1, real_key2) else ""))
    print("\n耗时          : %.2f 秒（等效约 2^17，暴力搜索需要 2^32）" % elapsed)

    print("\n结论：密钥长度翻倍 ≠ 安全性翻倍。")
    print("      这正是 2DES 被淘汰、3DES 改用 EDE 结构的原因。")


if __name__ == "__main__":
    main()
